<?php

use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../src/Hello.php';

final class HelloTest extends TestCase
{
    public function testSay(): void
    {
        $h = new Hello();
        $this->assertSame("Hello", $h->say());
    }
}