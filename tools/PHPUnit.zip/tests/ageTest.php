<?php

use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../src/age.php';

final class ageTest extends TestCase
{
    public function testAge(): void
    {
        $h = new age();
        $this->assertSame("Adult", $h->getAge());
    }
}