<?php

class Hello
{
    public function say(): string
    {
        return "Hello";
    }
}