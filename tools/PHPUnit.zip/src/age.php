<?php
class age
{
  public function getAge(): string
  {
    $age = 20; 
    if ($age >= 18) {
      return "Adult";
    } else {
      return "Minor";
    }
  }
}
